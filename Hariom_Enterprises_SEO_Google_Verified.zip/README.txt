# Hariom Enterprises — SEO-ready website

## Included
- SEO title and meta descriptions
- Local Raipur keyword targeting
- Product landing pages
- Internal linking
- Responsive design
- WhatsApp enquiry buttons
- FAQ content
- robots.txt
- sitemap.xml
- LocalBusiness structured data

## Contact
Phone/WhatsApp: +91 88714 63799
Email: hariomentp888@gmail.com
Address: Block No. 1, Plot No. 159, Transport Nagar, Raipur, Chhattisgarh 493221

## IMPORTANT BEFORE PUBLISHING
Replace `YOUR-GITHUB-USERNAME` in:
- every HTML canonical URL / structured-data URL
- robots.txt
- sitemap.xml

with your actual GitHub username.

Then submit the sitemap in Google Search Console:
https://search.google.com/search-console/about

## Pages
index.html
ms-plates-raipur.html
ms-pipes-raipur.html
c-purlins-raipur.html
z-purlins-raipur.html
solar-purlins-raipur.html
structural-steel-raipur.html
contact.html
style.css
script.js
robots.txt
sitemap.xml
